<?php

$id=filter_input(INPUT_POST, 'id');

$conexao= mysqli_connect("localhost", "root", "root", "descanso" );
if (!$conexao){ 
echo "Ops.. erro.";
exit;

}

$sql="DELETE FROM folga where id=".$id;

$remove= mysqli_query($conexao, $sql );

if(!$remove){

header("Location:exibe.php? remove=false");


exit;

}

header("Location:exibe.php? remove=true");

?>