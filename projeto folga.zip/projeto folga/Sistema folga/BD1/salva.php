<?php

include "edita.php ";

$novoid=filter_input(INPUT_POST, 'id');
$novocolaborador= filter_input(INPUT_POST, "colaborador"); 
$novofolga=filter_input(INPUT_POST, "folga");
$novodata=filter_input(INPUT_POST, "data");
$novodata2=filter_input(INPUT_POST, "data2");
$novodata3=filter_input(INPUT_POST, "data3");
$novodata4=filter_input(INPUT_POST, "data4");
$novohorario=filter_input(INPUT_POST, "horario");
$novosupervisor=filter_input(INPUT_POST, "supervisor");

////Estabelece a conexão com o mysql
    $conexao = mysqli_connect("localhost","root","root","descanso");
    if( !$conexao ){
        header("Location:exibe.php?alteracao=false");
        exit;
    }
    //Executa a atualização no banco de dados
    $sql = "UPDATE folga SET colaborador='" .$novocolaborador. "', folga='".$novofolga."' ,data='" .$novodata. "', data2='".$novodata2."', data3='".$novodata3."'  , data4= '".$novodata4."'  ,  horario='".$novohorario."', supervisor='".$novosupervisor."'  WHERE id=".$id;
    $update = mysqli_query($conexao, $sql);

    //Se não deu certo, redireciona pra exibe.php com alteracao igual a false
    if( !$update ){
        header("Location:exibe.php?alteracao=false");
        exit;
    }

    //se tudo deu certo, redireciona pra exibe.php com alteracao igual a true
    header("Location:exibe.php?alteracao=true");
?>
 