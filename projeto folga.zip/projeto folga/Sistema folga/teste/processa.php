<?php


$produto1 = $_POST['produto1'];
$produto2 = $_POST['produto2'];
$resultado = $_POST['resultado'];


echo "Produto um : $produto1" <br>;

echo "Produto dois : $produto2" <br>;

echo "Total:   $resultado" <br>;


?>