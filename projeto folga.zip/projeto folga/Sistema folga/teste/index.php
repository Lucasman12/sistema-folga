<script type="text/javascript">
function id(valor_campo)

{

return document.getElementById(valor_campo);

}

function getValor(valor_campo)

{

var valor  = document.getElementById(valor_campo).value.replace(',',',');

/*document.write("valor: "+ valor");*/

return parseFloat(valor) * 100;

}


function soma()


{

var total =  getValor('produto2') + getValor('produto1');
id('resultado').value = total/100;

}

</script>


<form method = "POST" action = "processa.php" >
Produto um <input name= "produto1"  id="produto1"  value ="8,40"><br><br>
Produto dois <input name= "produto2"  id="produto2"  value ="1,25 " onblur="soma()"><br><br>
Valor total: <input name = "resultado" readonly id="resultado"><br><br>
<input type="submit" value = "Cadastrar">

</form>

